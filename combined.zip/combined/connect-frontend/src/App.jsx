//App.jsx

import './App.css';
import { Route, Routes } from 'react-router-dom';
import RegistrationForm from './pages/register/RegistrationForm';
import UserList from './pages/userList/UserList';


function App() {

  return (
    <>
      <div>
        <Routes>
          <Route path="/" element={<RegistrationForm />} />
          <Route path="/user-list" element={<UserList />} />
        </Routes>
      </div>
    </>

  );
}

export default App;
