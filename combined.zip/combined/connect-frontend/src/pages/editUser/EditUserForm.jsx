
import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import '../register/register.css';

const EditUserForm = ({ user, onSave, onCancel }) => {
    const [formData, setFormData] = useState({
        name: '',
        mobile: '',
        email: '',
        address: '',
        profileImage: null,
    });

    useEffect(() => {
        setFormData({
            name: user.name,
            mobile: user.mobile,
            email: user.email,
            address: user.address,
            profileImage: user.profileImage,
        });
    }, [user]);

    const handleChange = (e) => {
        const { name, value, files } = e.target;
        setFormData({
            ...formData,
            [name]: files ? files[0] : value,
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave(user.id, formData);
    };

    return (
        <form className="registration-form" onSubmit={handleSubmit}>
            <h1>Edit User Details</h1>
            <div className="form-group">
                <label htmlFor="name">Name:</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                />
            </div>
            <div className="form-group">
                <label htmlFor="mobile">Mobile Number:</label>
                <input
                    type="tel"
                    id="mobile"
                    name="mobile"
                    value={formData.mobile}
                    onChange={handleChange}
                    required
                />
            </div>
            <div className="form-group">
                <label htmlFor="email">Email Address:</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                />
            </div>
            <div className="form-group">
                <label htmlFor="address">Address:</label>
                <input
                    type="text"
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    required
                />
            </div>
            <div className="form-group">
                <label htmlFor="profileImage">Profile Image:</label>
                <input
                    type="file"
                    id="profileImage"
                    name="profileImage"
                    onChange={handleChange}
                    accept="image/*"
                />
            </div>

            <button type="submit" className="submit-button">Update</button>
            <button type="button" className="cancel-button" onClick={onCancel}>Cancel</button>
        </form>
    );
};

export default EditUserForm;
