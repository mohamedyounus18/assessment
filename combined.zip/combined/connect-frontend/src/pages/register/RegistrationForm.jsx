// src/components/RegistrationForm.js

import React, { useState } from 'react';
import { apiForFiles } from '../../services/axiosApi';
import { toast } from 'react-toastify';
import './register.css';

const RegistrationForm = ({ onRegisterSuccess, onCancel }) => {
    const [formData, setFormData] = useState({
        name: '',
        mobile: '',
        email: '',
        address: '',
        profile_image: null,
    });

    const handleChange = (e) => {
        const { name, value, files } = e.target;
        setFormData({
            ...formData,
            [name]: files ? files[0] : value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log('Form data submitted:', formData);

        const data = new FormData();
        data.append('name', formData.name);
        data.append('mobile', formData.mobile);
        data.append('email', formData.email);
        data.append('address', formData.address);
        if (formData.profile_image) {
            data.append('profile_image', formData.profile_image);
        }

        try {
            const response = await apiForFiles.post('/register', data);
            console.log('Form data submitted:', response.data);
            toast.success('Registration successful!');
            setFormData({
                name: '',
                mobile: '',
                email: '',
                address: '',
                profile_image: null,
            });
            onRegisterSuccess();  // Call the callback to update the user list
        } catch (error) {
            console.error('Error submitting form data:', error);
            toast.error('Error submitting form data!');
        }
    };

    return (
        <form className="registration-form" onSubmit={handleSubmit}>
            <h1>Registration Form</h1>
            <div className="form-group">
                <label htmlFor="name">Name:</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                />
            </div>
            <div className="form-group">
                <label htmlFor="mobile">Mobile Number:</label>
                <input
                    type="tel"
                    id="mobile"
                    name="mobile"
                    value={formData.mobile}
                    onChange={handleChange}
                    required
                />
            </div>
            <div className="form-group">
                <label htmlFor="email">Email Address:</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                />
            </div>
            <div className="form-group">
                <label htmlFor="address">Address:</label>
                <input
                    type="text"
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    required
                />
            </div>
            <div className="form-group">
                <label htmlFor="profile_image">Profile Image:</label>
                <input
                    type="file"
                    id="profile_image"
                    name="profile_image"
                    onChange={handleChange}
                    accept="image/*"
                />
            </div>

            <div className="form-buttons">
                <button type="submit" className="submit-button">Register</button>
                <button type="button" className="cancel-button" onClick={onCancel}>Cancel</button>
            </div>
        </form>
    );
};

export default RegistrationForm;
