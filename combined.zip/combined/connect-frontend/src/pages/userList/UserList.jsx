import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './user-list.css';
import { api, profilePath } from '../../services/axiosApi';
import ConfirmationModal from '../../components/confirmation-modal/ConfirmationModal';
import { toast } from 'react-toastify';
import EditUserForm from '../editUser/EditUserForm';
import RegistrationForm from '../register/RegistrationForm';

const UserList = () => {
    const [users, setUsers] = useState([]);
    const [editingUser, setEditingUser] = useState(null);
    const [addingUser, setAddingUser] = useState(false);
    const [userToDelete, setUserToDelete] = useState(null);

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = () => {
        api.get('/users')
            .then(response => setUsers(response.data))
            .catch(error => console.error('Error fetching users:', error));
    };

    const handleEdit = (user) => {
        setEditingUser(user);
    };

    const handleDelete = (userId) => {
        setUserToDelete(userId);
    };

    const confirmDelete = () => {
        api.delete(`/users/${userToDelete}`)
            .then(() => {
                fetchUsers();
                setUserToDelete(null);
                toast.success('User removed successfully!');
            })
            .catch(error => console.error('Error deleting user:', error));
    };

    const handleSave = (userId, updatedData) => {
        const formData = new FormData();
        formData.append('name', updatedData.name);
        formData.append('mobile', updatedData.mobile);
        formData.append('email', updatedData.email);
        formData.append('address', updatedData.address);
        if (updatedData.profile_image) {
            formData.append('profile_image', updatedData.profile_image);
        }

        api.put(`/users/${userId}`, formData)
            .then(() => {
                fetchUsers();
                setEditingUser(null);
                toast.success("User updated successfully!");
            })
            .catch(error => console.error('Error updating user:', error));
    };

    const handleCancel = () => {
        setEditingUser(null);
        setAddingUser(false);
    };

    return (
        <div className="user-list-container">
            {editingUser ? (
                <EditUserForm
                    user={editingUser}
                    onSave={handleSave}
                    onCancel={handleCancel}
                />
            ) : addingUser ? (
                <RegistrationForm
                    onRegisterSuccess={() => {
                        fetchUsers();
                        setAddingUser(false);
                    }}
                    onCancel={handleCancel}
                />
            ) : (
                <>
                    <h1>Registered Users</h1>
                    <button className="add-button" onClick={() => setAddingUser(true)}>Add User</button>
                    <table className="user-list-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Mobile Number</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Profile Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map(user => (
                                <tr key={user.id}>
                                    <td>{user.name}</td>
                                    <td>{user.mobile}</td>
                                    <td>{user.email}</td>
                                    <td>{user.address}</td>
                                    <td>
                                        {user.profile_image ? (
                                            <img src={`${profilePath}/${user.profile_image}`} alt={`${user.name}'s profile`} className="profile-image" />
                                        ) : (
                                            'No Image'
                                        )}
                                    </td>
                                    <td>
                                        <button className="edit-button" onClick={() => handleEdit(user)}>Edit</button>
                                        <button className="delete-button" onClick={() => handleDelete(user.id)}>Delete</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {userToDelete !== null && (
                        <ConfirmationModal
                            message="Are you sure you want to delete this user?"
                            onConfirm={confirmDelete}
                            onCancel={() => setUserToDelete(null)}
                        />
                    )}
                </>
            )}
        </div>
    );
};

export default UserList;
