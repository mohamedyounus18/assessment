import axios from "axios";

const serverUrl = "http://localhost:8000"
const apiUrl = `${serverUrl}/api`

// Create Axios instances for different purposes
const createAxiosInstance = (baseURL, headers) => {
    return axios.create({
        baseURL,
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            ...headers, // Additional headers if needed
        },
    });
};

// Create a standard API Axios instance
const api = createAxiosInstance(apiUrl, {});

// Create an Axios instance for handling file uploads
const apiForFiles = createAxiosInstance(apiUrl, {
    "Content-Type": "multipart/form-data",
});

// Create an Axios instance for file downloads
const apiForFileDownload = createAxiosInstance(apiUrl, {
    "Content-Type": "application/json",
    Accept: "application/json",
    responseType: "blob",
});


// Flag to prevent multiple dialogs
let isSessionExpiredDialogShown = false;

// Axios interceptors for handling responses
api.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        console.log("Error =>", error);
        // Handle error responses
        if (error.response) {
            if (error.response.status === 401 && error.response.data.message === 'Unauthorized') {
                console.log("Unauthorized request");
                localStorage.clear();
                window.location.href = "/";
            }

            if (error.response.status === 440 && !isSessionExpiredDialogShown) {
                // Display a simple alert with only an "OK" button
                isSessionExpiredDialogShown = true;
                window.alert("Session Expired. Please login again.");
                localStorage.clear();
                window.location.href = "/";
            }
        }
        return Promise.reject(error);
    }
);


const profilePath = `${serverUrl}/storage/`

// Export the Axios instances and event dispatcher
export { api, apiForFiles, apiForFileDownload, profilePath };
